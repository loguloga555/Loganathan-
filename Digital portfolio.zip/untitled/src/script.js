// ...

// Copy email
copyEmail.addEventListener('click', function(){
  const email = 'bloganathan@example.com';
  navigator.clipboard.writeText(email).then(()=>{
    this.textContent = 'Copied';
    setTimeout(()=> this.textContent = 'Copy email',1300);
  });
});

// Form submit
contactForm.addEventListener('submit', function(e){
  e.preventDefault();
  const fd = new FormData(this);
  const name = fd.get('name');
  const email = fd.get('email');
  const message = fd.get('message');
  if(!name || !email ||